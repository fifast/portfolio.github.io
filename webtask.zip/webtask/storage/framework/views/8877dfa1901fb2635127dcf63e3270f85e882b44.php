<!DOCTYPE html>
<html>
<head>
     <title> 10th Task </title>
<style> 
         body{color : white;}
         body{background-color:rgb(52,52,52)
;}
         table{background-color : rgb(8,8,8);}
</style>
</head>
<center><body> <h1> 100% Approval </h1>
           <p> One of the <strong>best rated</strong> items of recent item </p>
         <table border= "1">
    <tbody>
        <td><p>&emsp;Not only was customer<strong> support very fast</strong>, but the design is
            <br>&emsp; <strong>very professional</strong>.</p>
            <p> &emsp;Will definitely be looking for new product and updates
            <br>&emsp; in the future from this user.</p>
            <p> &emsp;Thank you! </p> 
         <p> &emsp; <img src="<?php echo e(asset('data/images/icon 3.jpg')); ?> " height="40"><font size="2">Web Developer</font> </p>
</td>
    </tbody>   
       </table>
<br> 
<table border= "1">
    <tbody>
        <td><p>&emsp;This code for this <strong>template is fantastic</strong> and I have seen
            <br>&emsp; quite a few I most recently went through the pain of porting
            <br>&emsp; a wordpress theme to a custom right side "Shiver"  </p>
            <p>&emsp;  This template however is fab codingsdev ftw!</p>
           <p> &emsp;<img src="<?php echo e(asset('data/images/icon 3.jpg')); ?> " height="40"><font size="2">Web Developer</font> </p>
        </td> 
    </tbody>   
       </table>
<br>
<table border= "1">
    <tbody>
        <td><p>&emsp;A <strong>cool theme</strong>, good choice for startup and young Agencies.  </p>
            <p>&emsp;<strong>Great rate quality</strong> and price and helpful team  </p>
          <p> &emsp; <img src="<?php echo e(asset('data/images/icon 3.jpg')); ?>  " height="40"><font size="2">Web Developer</font> </p>
        </td> 
    </tbody>   
       </table>
<br>
<table border= "1">
    <tbody>
        <td><p>&emsp; <strong>Fantastic Theme!</strong>  </p>
            <p>&emsp;<strong>Easy to use</strong> and looks great! &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;  </p>
<p>&emsp;<img src="<?php echo e(asset('data/images/icon 3.jpg')); ?>  " height="40"><font size="2">Web Developer</font> </p> 
        </td> 
    </tbody>   
       </table>
</body></center>
</html><?php /**PATH C:\xampp\htdocs\webtask\resources\views/10task.blade.php ENDPATH**/ ?>