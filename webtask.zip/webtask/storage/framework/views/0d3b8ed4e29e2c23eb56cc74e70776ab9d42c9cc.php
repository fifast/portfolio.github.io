<!DOCTYPE.html>
<html>
    <head>
        <title>task01</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo e(asset('data/css/bootstrap.min.css')); ?>">
        <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
        <script src="<?php echo e(asset('data/js/bootstrap.bundle.min.js')); ?>"></script>
    </head>
    <div class="container-fluid" style="background-color:rgb(22, 22, 22);">
        <div class="row">
        <div class="col-9" >
        <nav class="navbar navbar-expand-sm">
            <div class="container-fluid" >
              <ul class="navbar-nav">
                <li class="nav-item">
               <a class="nav-link" href="#" style="color:white">Logo</a>
                </li>
                &emsp; <li class="nav-item">
                 <a class="nav-link" href="#" style="background-color:black;color:rgb(255, 255, 255)">Home</a>
                </li>
                &emsp; <li class="nav-item">
                 <a class="nav-link" href="#" style="color:rgb(255, 255, 255)">About</a>
                </li>
                &emsp; <li class="nav-item">
                 <a class="nav-link" href="#" style="color:rgb(255, 255, 255)">Products</a>
                  </li>
                  &emsp; <li class="nav-item">
                    <a class="nav-link" href="#" style="color:rgb(255, 255, 255)">Services</a>
                     </li>
              </ul>
            </div>
          </nav>
        </div>
        <div class="col-md-3" style="margin-top:2vh;padding-left:5vh;">
            <input type="text" style="width:25vh;height:5vh;">
            <input type="submit" style="">
        </div>
    </div>
    </div>
    <div class="container-fluid" style="background-color:#88a807">
       <center style="padding-top:20vh;padding-bottom:20vh"> 
        <h1 style="font-size:13vh;color:#adff33">Dramatically Engage</h1> 
    <p style="font-size:3vh;color:#b6ff47">Lorem ipsum dolor sit amet consectetur adipisicing elit. Magni, repellendus. Ut earum eos eaque alias.</p>
    <button style="background-color:rgb(67, 67, 176);color:white;border-radius:5px;width:25vh;height:6vh;border:none;">Engage Now</button>
    </center>

    </div>
    <div class="container-fluid">
        <div class="row" style="padding-top:5vh;">
           <center> <h1>Superior Collaboration<span style="font-size:5vh;color:rgb(184, 184, 184)">Visualize Quality</span></h1> 
          <p style="color:rgb(150, 150, 150)">Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptas quasi, non placeat deserunt omnis animi consectetur molestias exercitationem necessitatibus odio expedita quidem, inventore laudantium repellat dolorum nesciunt earum harum vel.</p>
        </center>
        </div>
    </div>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-4" >
          <center><p style="font-size:7vh;color:rgb(150, 150, 150);width:350;background-color:rgb(207, 207, 207);padding-top:17vh;padding-bottom:17vh;">700x300</p>
          <h2 style="color:blue;">Efficiently Unleash</h2>
          <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit.Commodi Commodi  quaerat adipisci deleniti accusantium exercitationem facilis aspernatur libero?</p>
        </center>
        </div>
        <div class="col-md-4" style="">
          <center><p style="font-size:7vh;color:rgb(150, 150, 150);width:350;background-color:rgb(207, 207, 207);padding-top:17vh;padding-bottom:17vh;">700x300</p>
          <h2 style="color:blue;">Completely Synergize</h2>
          <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Commodi  quaerat Commodi  quaerat adipisci deleniti accusantium exercitationem facilis aspernatur libero?</p>
        </center>
        </div>
        <div class="col-md-4" style="">
          <center><p style="font-size:7vh;color:rgb(150, 150, 150);width:350;background-color:rgb(207, 207, 207);padding-top:17vh;padding-bottom:17vh;">700x300</p>
          <h2 style="color:blue;">Dynamically Procrastinate</h2>
          <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Commodi  quaerat adipisci  quaerat adipisci deleniti accusantium exercitationem facilis aspernatur libero?</p>
        </center>
        </div>
      </div>
    </div><?php /**PATH C:\xampp\htdocs\webtask\resources\views/newtask03.blade.php ENDPATH**/ ?>