<!DOCTYPE.html>
<html>
    <head>
        <title>task01</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="<?php echo e(asset('data/css/bootstrap.min.css')); ?>">
        <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
        <script src="<?php echo e(asset('data/js/bootstrap.bundle.min.js')); ?>"></script>
        <style>
        .div1{
         background-color: black;
         width:100%;

        }
            </style>
    </head>
    <body>
        <div class="container-fluid div1">
            <div class="row">
                <div class="col-md-6">
              <img src="https://i.dlpng.com/static/png/6849424_preview.png" height="70px" width="70px">
              <span style="font-size:4vh;color:white;font-family:Verdana, Geneva, Tahoma, sans-serif">
                SoundAMP</span>
                </div>
                <div class="col-md-6" style="padding-top:3vh;padding-left: 8vh;">
 <span style="font-size:12px;color:white;font-family:Verdana, Geneva, Tahoma, sans-serif"> HTML TEMPLATES&emsp;HTML TEMPLATES2&emsp;Watch Video</span>
<button style="height:6vh;background-color:rgb(95, 199, 255);font-size:13px;color:white;font-family:Verdana, Geneva, Tahoma, sans-serif;border-radius:25px"><small>DOWNLOAD NOW</small></button>
<img src="https://www.shareicon.net/data/512x512/2015/10/07/113974_media_512x512.png" height="20px" width="20px">
<img src="https://3.bp.blogspot.com/-S8HTBQqmfcs/XN0ACIRD9PI/AAAAAAAAAlk/A_3ZXg7xO4YyGrKDhMpr6YRgrtOMn9tHwCLcBGAs/s1600/f_logo_RGB-Blue_1024.png" height="20px" width="20px">
<img src="https://www.allgoodcycling.co.uk/assets/twitter-logo.png" height="18px" width="20px">
<img src="https://iconsplace.com/wp-content/uploads/_icons/0000ff/256/png/pinterest-icon-2-256.png" height="20px" width="20px">
<img src="https://icons-for-free.com/download-icon-color+linkedin+icon-1320168273298536151_512.png" height="20px" width="20px">
</div>
            </div>
        </div>

        <div class="container-fluid" style="background-color:rgb(65, 2, 124);font-size:31px;color:white;font-family:Comic Sans MS, Comic Sans, cursive;">
           <center> ABOUT US</center>
            <div class="container-fluid" style="width:100%;margin-top:4vh;background-color:rgb(148, 57, 234);color:white;">
                <div class="row" >
                    <div class="col-md-6 img-fluid">
<img src="https://www.trustedreviews.com/wp-content/uploads/sites/54/2022/05/ROG-Flow-X16-7-920x613.jpg" style="margin-top:7vh;" height="300px" width="520px">
                    </div>
                    <div class="col-md-6" style="margin-top:7vh;margin-bottom:6vh;">
<p style="font-size:9px">We work with professional as well as with the people who first came to the recording studio </p>
       <h3>Simple HTML Website template</h3> <br> 
       <h5>Give you a listener a professional record of your work!</h5> 
       <p style="font-size:12px">-Professionally we will write a song; <br>
          - We will help to make an advertising audio-movie or jingles; <br>
          - We will voice the video; <br>
          - We will arrange for the author song; <br>
          -  We will write congratulation to any events; <br>
          - Sound recording of children;</p> 
          <img src="https://aur.tv/wp-content/uploads/2021/12/youtube-icon-1.png" height="60" width="60">
          <img src="https://icon-library.com/images/white-facebook-icon-png/white-facebook-icon-png-29.jpg" height="30" width="30">
         &ensp; <img src="https://www.nicepng.com/png/full/28-284246_linkedin-01-icon-linkedin-white-color.png" height="30" width="30">
                    
                   </div>
                </div>
            </div>
            <center style="margin-top:5vh;padding-bottom:2vh"> ABOUT THE STUDIO</center>
        </div>
    </body>
<?php /**PATH C:\xampp\htdocs\webtask\resources\views/newtask 1.blade.php ENDPATH**/ ?>