<!DOCTYPE html>
<html>
<head>
     <title> HTML Language </title>
     <style>
            h1,h2,h3 {color:red;}
     </style>
</head>
      <body>
             <h1> HTML language </h1> 
         <p> HTML language is a basic knowledge you need to know create websites. It is quite simple and<br> all the websites are using it.
             Advanced websites are using a few more languauges together with<br> HTML. </p>
             <h2> Editor </h2> 
         <p> To write a HTML code it's not a good idea to use a simple Notepad becuase it miss alot of<br> features like code highlighting 
             or UTF encoding support. </p>
             <h3> PSPad </h3> 
         <p> At the beginning webdesigners may use Notepad++which is a really good editor. </p>
             <h2> HTML page </h2> 
         <p> HTML page can be created easily,basically it's just a text document. </p>
             <h3> Tags </h3>
         <p> HTML consists from marks(so-called tags).By itself it allows to give the elements on the page<br> some meaning and this  is it's main task.
             Firstly HTML was used for styling of pages but<br> the resulting websites were confusing so it has been limited just to web content. </p>
             <h3> Doctype </h3>
         <p> The very first tag in HTML document is doctype. It defines that the text file is a HTML documents . </p>
             <h3> HTML </h3>
         <p> Whole document is placed inside the HTML tag .This tag is divided into 2 tags: head and body. </p>

 </body>
</html>