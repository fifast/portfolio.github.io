<!DOCTYPE html>
<html>
<head>
     <title> 8th Task </title>
            <style>
                   
                   thead {background-color:red;}
                   thead {color:white;}
                   tbody {background-color:gold;}
                   h2{ color: indigo;}
                  
           </style>
</head>
<body> 
   <p>  <font size="9"> My Awesome Blog </font> &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;\\&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<a href="#home " > Home </a>&ensp; <a href="#about " > About </a></p>
   <img src="{{ asset('data/images/Artboard.webp') }}" width="1000" height="400">
<h2><u> Title of the first Blog </u></h2><p>  
<table border= "1">
    <thead> <th>Useful Links</th> </thead>
    <tbody> <tr> <td><ul><li><a href="https://azizali.com/ ">AzizAli.com</a></li> <li><a href="https://ilovecoding.org/ ">IloveCoding.org</a>
    </li></ul> </td> </tr></tbody>
</table>
<br>You will learn how to see the code of other websites using a tool called Chrome developer tools so you can see how 
<br>other websites are coded so you can get inspiration from them and code your websites and enhance your websites 
<br> accordingly.You will learn how to make headlines titles, forms, tables, paragraphs.</p>
<hr>
<h2><u> Title of the first Blog</u> </h2>
<p>You will learn how to see the code of other websites using a tool called Chrome developer tools so you can see how 
<br>other websites are coded so you can get inspiration from them and code your websites and enhance your websites 
<br> accordingly.You will learn how to make headlines titles, forms, tables, paragraphs.</p>
</body>
</html>