<!DOCTYPE html>
<html>
<head>
     <title> 7th Task </title>
<style>
        
              body  { background-color:deepskyblue;}
        table{background-color:powderblue;}

</style>
</head>
      <center> <body> 
               
       <table border= "5">
    <thead>
        <th> Victoria Journal </th>  
    </thead>
             <tbody>
                    <tr>
                        <td> 
                           &emsp;&ensp;So fesh and so clean &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&ensp;
                        </td>
                   </tr>
            </tbody>
       </table>
        <table border= "5">
    <thead>
        <th>04/09/08:Spatulas </th>  
    </thead>
             <tbody>
                    <tr>
                        <td> 
           <img src="{{ asset('data/images/spoon.jpg') }} " height="150" > 
                          <br>&emsp; Yesterday I went to the store and got some much needed Spatulas!( what better way to say I love myself)&emsp;&emsp;&emsp;&nbsp;
                          <br> &emsp;  than to my by myself Spatulas ?)<br>
                        </td>
                   </tr>
            </tbody>
      </table>
         
        <table border= "5" >
    <thead>
        <th>04/08/08:Cookie Monster cupcakes  </th>  
    </thead>
             <tbody>
                    <tr>
                        <td> 
           <img src="{{ asset('data/images/cookie monster.jpg') }} " height="150" > <br>
                          <br>&emsp; My favourite cartoon character is cookie Monster and my favourite dessert is cupcakes so cookie Monster
                          <br>&emsp; are the best of both world.<br>
                          <br>&emsp; Did you know? cookie Monster once said "Sometime me think what is love and then me think love is what last &ensp;
                          <br>&emsp; cookies for me give up the last cookie for you."I wonder if the same applies for cupcake? (if so,I don't
                          <br>&emsp;  think I can never love anyone! )<br>
           
                        </td>
                   </tr>
            </tbody>
      </table>
</body> </center>
</html>